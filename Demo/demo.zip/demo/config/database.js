// config/database.js
module.exports = {

    'url' : 'mongodb+srv://becca:becca@clusterdemo.rpiuh.mongodb.net/test', // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
    'dbName': 'demo'
};
